from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import pandas as pd
import os
import logging

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
CORS(app)  # Enable CORS for API requests

# Default CSV path
CSV_PATH = os.path.join(os.path.dirname(__file__), 'Dogomo.csv')

@app.route('/')
def home():
    """Render the home page with the recommendation form"""
    return render_template('index.html')

@app.route('/dog/<breed_name>')
def dog_details(breed_name):
    """Render the dog details page for a specific breed"""
    return render_template('dog_details.html', breed_name=breed_name)

@app.route('/recommend', methods=['POST'])
def recommend():
    """API endpoint to get dog breed recommendations based on user preferences"""
    try:
        data = request.get_json()
        logger.debug(f"Received recommendation request: {data}")

        # Get parameters from request
        traits = data.get("traits", "")
        budget = int(data.get("budget", 0))
        longevity = int(data.get("longevity", 0))
        min_temp = int(data.get("min_temp", -100))
        max_temp = int(data.get("max_temp", 100))

        # Process the dataset
        df = pd.read_csv(CSV_PATH)
        
        # Process the Price column (remove range and convert to numeric)
        df["Price_Processed"] = df["Price"].str.split("-").str[0].str.strip().astype(int)
        
        # Process the Longitivity column (extract minimum value from range)
        df["Longevity_Min"] = df["Longitivity"].str.split("-").str[0].astype(int)
        
        # Filter based on criteria
        if traits:
            match_traits = df["Character Traits"].str.contains(traits, case=False, na=False)
        else:
            # If no traits specified, consider all breeds as matching
            match_traits = pd.Series([True] * len(df))
            
        recommended = df[
            (df["Price_Processed"] <= budget) &
            (df["Longevity_Min"] >= longevity) &
            (df["Min Temp"] <= min_temp) &
            (df["Max Temp"] >= max_temp) &
            match_traits
        ]
        
        not_recommended = df.drop(recommended.index)
        
        # Fields to include in the response
        fields = ["Breed Name", "Maintainance per month", "Character Traits", "Longitivity", "Price", "Min Temp", "Max Temp"]
        
        # Convert to list of dictionaries for JSON serialization
        def process_breed_data(row):
            data = {field: row[field] for field in fields}
            
            # Generate image URL based on breed name
            breed_name = row["Breed Name"]
            image_path = f"/static/assets/{breed_name.lower().replace(' ', '_')}.jpg"
            
            # Use default dog image as fallback
            data["image"] = "/static/assets/dog_default.svg"
            
            # Add specific images for some breeds (would normally be loaded from a directory)
            if breed_name == "Labrador Retriever":
                data["image"] = "/static/assets/labrador_retriever.jpg"
            elif breed_name == "German Shepherd":
                data["image"] = "/static/assets/german_shepherd.jpg"
            elif breed_name == "Golden Retriever":
                data["image"] = "/static/assets/golden_retriever.jpg"
            elif breed_name == "Beagle":
                data["image"] = "/static/assets/beagle.jpg"
            elif breed_name == "Bulldog":
                data["image"] = "/static/assets/bulldog.jpg"
            elif breed_name == "Poodle":
                data["image"] = "/static/assets/poodle.jpg"
            
            return data
        
        # Limit recommended to top 4 if there are more than 4
        recommended = recommended.head(4) if len(recommended) > 4 else recommended
        
        recommended_list = [process_breed_data(row) for _, row in recommended.iterrows()]
        not_recommended_list = [process_breed_data(row) for _, row in not_recommended.head(4).iterrows()]
        
        logger.debug(f"Found {len(recommended_list)} recommended breeds and {len(not_recommended_list)} non-recommended breeds")
        
        return jsonify({
            "recommended": recommended_list,
            "not_recommended": not_recommended_list
        })

    except Exception as e:
        logger.error(f"Error in recommendation: {str(e)}", exc_info=True)
        return jsonify({"error": str(e)}), 500

@app.route('/api/breeds', methods=['GET'])
def get_all_breeds():
    """API endpoint to get all dog breeds from the dataset"""
    try:
        df = pd.read_csv(CSV_PATH)
        breeds = df["Breed Name"].tolist()
        return jsonify({"breeds": breeds})
    except Exception as e:
        logger.error(f"Error retrieving breeds: {str(e)}", exc_info=True)
        return jsonify({"error": str(e)}), 500

@app.route('/api/breed/<breed_name>', methods=['GET'])
def get_breed_details(breed_name):
    """API endpoint to get details for a specific breed"""
    try:
        df = pd.read_csv(CSV_PATH)
        breed = df[df["Breed Name"].str.lower() == breed_name.lower()]
        
        if breed.empty:
            return jsonify({"error": "Breed not found"}), 404
        
        breed_data = breed.iloc[0].to_dict()
        return jsonify(breed_data)
    except Exception as e:
        logger.error(f"Error retrieving breed details: {str(e)}", exc_info=True)
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    # Run the Flask app
    app.run(host='0.0.0.0', port=5000, debug=True)
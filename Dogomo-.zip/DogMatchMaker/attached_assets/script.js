document.getElementById("recommend-form").addEventListener("submit", function(e) {
  e.preventDefault();

  const traits = document.getElementById("traits").value;
  const budget = document.getElementById("budget").value;
  const longevity = document.getElementById("longevity").value;
  const min_temp = document.getElementById("min-temp").value;
  const max_temp = document.getElementById("max-temp").value;

  fetch("http://127.0.0.1:5000/recommend", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ traits, budget, longevity, min_temp, max_temp })
  })
  .then(res => res.json())
  .then(data => displayRecommendations(data));
});

function displayRecommendations(data) {
  const recommendedGrid = document.getElementById("recommended-grid");
  const notRecommendedGrid = document.getElementById("not-recommended-grid");
  recommendedGrid.innerHTML = "";
  notRecommendedGrid.innerHTML = "";

  const createCard = (dog) => `
    <div class="breed-card">
      <img src="${dog.image}" alt="${dog['Breed Name']}">
      <h3>${dog['Breed Name']}</h3>
      <p><strong>Traits:</strong> ${dog['Character Traits']}</p>
      <p><strong>Maintainance:</strong> ${dog['Maintainance per month']}</p>
      <p><strong>Lifespan:</strong> ${dog['Longitivity']} years</p>
      <p><strong>Price:</strong> ₹${dog['Price']}</p>
    </div>
  `;

  data.recommended.forEach(dog => {
    recommendedGrid.innerHTML += createCard(dog);
  });

  data.not_recommended.forEach(dog => {
    notRecommendedGrid.innerHTML += createCard(dog);
  });
}

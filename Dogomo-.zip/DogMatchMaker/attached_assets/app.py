from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from utils.predictor import recommend_dogs
import os

# Set up Flask app and CORS
app = Flask(__name__, static_folder='../static')
CORS(app)  # Enable CORS for frontend-backend communication

@app.route('/')
def home():
    return "Dogomo Backend is Running 🐶"

@app.route('/recommend', methods=['POST'])
def recommend():
    try:
        data = request.get_json()

        # Parse and convert inputs safely
        traits = data.get("traits", "")
        budget = int(data.get("budget", 0))
        longevity = int(data.get("longevity", 0))
        min_temp = int(data.get("min_temp", -100))
        max_temp = int(data.get("max_temp", 100))

        # Call the recommendation engine
        result = recommend_dogs(traits, budget, longevity, min_temp, max_temp)
        return jsonify(result)

    except Exception as e:
        print("❌ ERROR:", str(e))
        return jsonify({"error": str(e)}), 500

@app.route('/static/<path:filename>')
def serve_image(filename):
    static_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '../static'))
    return send_from_directory(static_path, filename)

if __name__ == '__main__':
    app.run(debug=True)

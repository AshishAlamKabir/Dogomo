// frontend/scripts/chatbot.js

document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("chatbot-form");
    const input = document.getElementById("user-input");
    const resultBox = document.getElementById("recommendation-results");
  
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const userInput = input.value.trim();
  
      if (!userInput) {
        alert("Please enter your preferences.");
        return;
      }
  
      // Display loading state
      resultBox.innerHTML = "<p>Finding the best dog breeds for you...</p>";
  
      try {
        const response = await fetch("http://127.0.0.1:5000/predict", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ user_input: userInput }),
        });
  
        const data = await response.json();
  
        if (data.status === "success") {
          displayRecommendations(data.recommendations);
        } else {
          resultBox.innerHTML = `<p>Error: ${data.message}</p>`;
        }
      } catch (error) {
        resultBox.innerHTML = `<p>Something went wrong. Try again later.</p>`;
        console.error("Fetch error:", error);
      }
    });
  
    function displayRecommendations(recommendations) {
      resultBox.innerHTML = "<h3>Top Dog Breed Matches:</h3>";
      recommendations.forEach((rec, index) => {
        resultBox.innerHTML += `
          <div class="recommendation">
            <h4>${index + 1}. ${rec.Breed}</h4>
            <p>${rec.Description}</p>
            <small>Match Score: ${rec.Score.toFixed(2)}</small>
            <hr>
          </div>
        `;
      });
    }
  });
  
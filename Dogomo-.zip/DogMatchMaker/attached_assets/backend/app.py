from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from utils.predictor import recommend_dogs
import os

# Set up Flask app and CORS
app = Flask(__name__, static_folder='../static')
CORS(app)  # Enable CORS for frontend-backend communication

@app.route('/')
def home():
    return "Dogomo Backend is Running 🐶"

@app.route('/recommend', methods=['POST'])
def recommend():
    try:
        data = request.get_json()

        # Parse and convert inputs safely
        traits = data.get("traits", "")
        budget = int(data.get("budget", 0))
        longevity = int(data.get("longevity", 0))
        min_temp = int(data.get("min_temp", -100))
        max_temp = int(data.get("max_temp", 100))

        # Call the recommendation function
        recommendations = recommend_dogs(traits, budget, longevity, min_temp, max_temp)

        # Limit to 4 results for each category
        recommended = recommendations["recommended"][:4]
        not_recommended = recommendations["not_recommended"][:4]

        # Return the response
        return jsonify({
            "recommended": recommended,
            "not_recommended": not_recommended
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.route('/static/<path:filename>')
def serve_image(filename):
    static_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '../static'))
    return send_from_directory(static_path, filename)

if __name__ == '__main__':
    app.run(debug=True)

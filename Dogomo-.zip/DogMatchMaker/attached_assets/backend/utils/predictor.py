import pandas as pd
import os

# CSV and image folder paths
CSV_PATH = r"C:\Users\ashis\Downloads\Dogomo\backend\model\Dogomo.csv"
IMAGE_FOLDER = r"C:\Users\ashis\Downloads\Dogomo\static"

def find_image_for_breed(breed_name):
    # Normalize the breed name for loose matching
    for file in os.listdir(IMAGE_FOLDER):
        if breed_name.lower() in file.lower():
            return f"/static/{file}"  # Flask will serve from 'static/' directory
    return None  # Return None if not found

def recommend_dogs(traits, budget, longevity, min_temp, max_temp):
    try:
        # Load the dataset
        df = pd.read_csv(CSV_PATH)

        # Ensure numeric columns
        df["Price"] = pd.to_numeric(df["Price"], errors='coerce')
        df["Longitivity"] = pd.to_numeric(df["Longitivity"], errors='coerce')
        df["Min Temp"] = pd.to_numeric(df["Min Temp"], errors='coerce')
        df["Max Temp"] = pd.to_numeric(df["Max Temp"], errors='coerce')

        # Filter recommended breeds
        recommended = df[
            (df["Price"] <= budget) &
            (df["Longitivity"] >= longevity) &
            (df["Min Temp"] <= min_temp) &
            (df["Max Temp"] >= max_temp) &
            (df["Character Traits"].str.contains(traits, case=False, na=False))
        ]

        not_recommended = df.drop(recommended.index)

        fields = ["Breed Name", "Maintainance per month", "Character Traits", "Longitivity", "Price"]

        # Convert to dicts and add image path
        def add_image_info(row):
            data = {field: row[field] for field in fields}
            data["image"] = find_image_for_breed(row["Breed Name"])
            return data

        recommended_list = [add_image_info(row) for _, row in recommended.iterrows()]
        not_recommended_list = [add_image_info(row) for _, row in not_recommended.iterrows()]

        return {
            "recommended": recommended_list,
            "not_recommended": not_recommended_list
        }

    except Exception as e:
        print("❌ ERROR:", str(e))
        return {
            "recommended": [],
            "not_recommended": [],
            "error": str(e)
        }

# Debug/Test
if __name__ == "__main__":
    results = recommend_dogs("friendly", 100000, 1, 10, 35)
    for breed in results["recommended"]:
        print("✅", breed)

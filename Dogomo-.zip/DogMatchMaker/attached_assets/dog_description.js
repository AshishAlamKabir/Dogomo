function getQueryParam(name) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(name);
}

const breed = getQueryParam("breed");
if (breed) {
    fetch("http://localhost:5000/recommend", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ traits: [], budget: 999999, min_temp: -50, max_temp: 100 })
    })
    .then(res => res.json())
    .then(data => {
        const dog = data.find(d => d.Breed.toLowerCase() === breed.toLowerCase());
        if (dog) {
            document.getElementById("dogName").textContent = dog.Breed;
            document.getElementById("dogTraits").textContent = dog.Traits;
            document.getElementById("dogPrice").textContent = dog.Price;
            document.getElementById("dogTemp").textContent = `${dog.MinTemp} - ${dog.MaxTemp}`;
            document.getElementById("dogTemperament").textContent = dog.Temperament || "Not specified";
            document.getElementById("dogActivity").textContent = dog.Activity || "Not specified";
            document.getElementById("dogLifespan").textContent = dog.Lifespan || "Not specified";

            const imagePath = `../static/dog_images/${dog.Breed.toLowerCase().replace(/ /g, "_")}.jpg`;
            const image = document.getElementById("dogImage");
            image.src = imagePath;
            image.onerror = () => {
                image.src = "../static/dog_images/default.jpg";
            };
        } else {
            document.body.innerHTML = "<p>Dog not found.</p>";
        }
    });
}
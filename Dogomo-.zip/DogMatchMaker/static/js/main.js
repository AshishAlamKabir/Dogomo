document.addEventListener('DOMContentLoaded', function() {
  // Get DOM elements
  const recommendForm = document.getElementById('recommend-form');
  const loadingIndicator = document.getElementById('loading');
  const resultsContainer = document.getElementById('results-container');
  const recommendedGrid = document.getElementById('recommended-grid');
  const notRecommendedGrid = document.getElementById('not-recommended-grid');

  // Add event listener to the form
  recommendForm.addEventListener('submit', async function(e) {
    e.preventDefault();
    
    // Get form values
    const traits = document.getElementById('traits').value;
    const budget = parseInt(document.getElementById('budget').value);
    const longevity = parseInt(document.getElementById('longevity').value);
    const minTemp = parseInt(document.getElementById('min-temp').value);
    const maxTemp = parseInt(document.getElementById('max-temp').value);
    
    // Show loading indicator
    loadingIndicator.classList.remove('d-none');
    resultsContainer.classList.add('d-none');
    
    try {
      // Make API request
      const response = await fetch('/recommend', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          traits: traits,
          budget: budget,
          longevity: longevity,
          min_temp: minTemp,
          max_temp: maxTemp
        })
      });
      
      // Parse JSON response
      const data = await response.json();
      
      // Check for errors
      if (data.error) {
        showError(data.error);
        return;
      }
      
      // Display results
      displayBreeds(data.recommended, recommendedGrid);
      displayBreeds(data.not_recommended, notRecommendedGrid);
      
      // Hide loading, show results
      loadingIndicator.classList.add('d-none');
      resultsContainer.classList.remove('d-none');
      
      // Scroll to results
      resultsContainer.scrollIntoView({ behavior: 'smooth' });
      
    } catch (error) {
      console.error('Error fetching recommendations:', error);
      showError('Failed to fetch recommendations. Please try again later.');
    }
  });
  
  // Function to display breeds in a grid
  function displayBreeds(breeds, gridElement) {
    // Clear the grid
    gridElement.innerHTML = '';
    
    // Check if we have breeds to display
    if (!breeds || breeds.length === 0) {
      gridElement.innerHTML = `
        <div class="col-12">
          <div class="alert alert-info">
            <i class="fas fa-info-circle me-2"></i>No matching breeds found.
          </div>
        </div>
      `;
      return;
    }
    
    // Add a title showing the result count
    if (gridElement.id === 'recommended-grid') {
      gridElement.innerHTML = `
        <div class="col-12 mb-3">
          <div class="alert alert-success">
            <i class="fas fa-check-circle me-2"></i>Found ${breeds.length} matching dog breeds for you!
          </div>
        </div>
      `;
    }
    
    // Add each breed to the grid
    breeds.forEach(breed => {
      // Create traits badges
      const traitsArray = breed['Character Traits'].split(',').map(trait => trait.trim());
      const traitBadges = traitsArray.map(trait => 
        `<span class="badge bg-secondary trait-badge">${trait}</span>`
      ).join('');
      
      // Extract price range
      const priceText = breed['Price'];
      
      // Create the card
      const card = document.createElement('div');
      card.className = 'col-md-6';
      card.innerHTML = `
        <div class="card breed-card h-100 mb-4">
          <div class="row g-0">
            <div class="col-5">
              <img src="${breed.image}" class="img-fluid rounded-start h-100 object-fit-cover" alt="${breed['Breed Name']}">
            </div>
            <div class="col-7">
              <div class="card-body">
                <h3 class="card-title h4">${breed['Breed Name']}</h3>
                <div class="d-flex flex-column gap-1">
                  <p class="card-text mb-1"><strong>Budget:</strong> ₹${priceText}</p>
                  <p class="card-text mb-1"><strong>Lifespan:</strong> ${breed['Longitivity']} years</p>
                  <p class="card-text mb-1"><strong>Maintenance:</strong> ₹${breed['Maintainance per month']}/month</p>
                </div>
                <div class="mt-2">
                  <a href="/dog/${encodeURIComponent(breed['Breed Name'])}" class="btn btn-sm btn-primary">
                    <i class="fas fa-info-circle me-1"></i>View Details
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      `;
      
      gridElement.appendChild(card);
    });
  }
  
  // Function to show error message
  function showError(message) {
    loadingIndicator.classList.add('d-none');
    resultsContainer.classList.remove('d-none');
    
    recommendedGrid.innerHTML = `
      <div class="col-12">
        <div class="alert alert-danger">
          <i class="fas fa-exclamation-circle me-2"></i>${message}
        </div>
      </div>
    `;
    
    notRecommendedGrid.innerHTML = '';
  }
});
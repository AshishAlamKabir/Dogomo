document.addEventListener('DOMContentLoaded', function() {
  // Get the breed name from the URL
  const urlParams = new URLSearchParams(window.location.search);
  const pathParts = window.location.pathname.split('/');
  const breedName = decodeURIComponent(pathParts[pathParts.length - 1]);
  
  // DOM elements
  const loadingIndicator = document.getElementById('loading');
  const errorContainer = document.getElementById('error-container');
  const errorMessage = document.getElementById('error-message');
  const dogDetails = document.getElementById('dog-details');
  
  // Elements to populate
  const pageTitle = document.getElementById('page-title');
  const dogName = document.getElementById('dog-name');
  const dogImage = document.getElementById('dog-image');
  const dogTraits = document.getElementById('dog-traits');
  const dogPrice = document.getElementById('dog-price');
  const dogMaintenance = document.getElementById('dog-maintenance');
  const dogLifespan = document.getElementById('dog-lifespan');
  const dogTempRange = document.getElementById('dog-temp-range');
  
  // Fetch the dog details
  async function fetchDogDetails() {
    try {
      // Send a request for all breeds
      const response = await fetch('/recommend', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          traits: '',
          budget: 999999,
          longevity: 0,
          min_temp: -100,
          max_temp: 100
        })
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch dog details');
      }
      
      const data = await response.json();
      
      // Combine recommended and not recommended breeds
      const allBreeds = [...data.recommended, ...data.not_recommended];
      
      // Find the requested breed
      const breed = allBreeds.find(b => b['Breed Name'].toLowerCase() === breedName.toLowerCase());
      
      if (!breed) {
        throw new Error('Breed not found');
      }
      
      // Update the page
      displayBreedDetails(breed);
      
    } catch (error) {
      console.error('Error:', error);
      showError(error.message);
    }
  }
  
  // Display the breed details
  function displayBreedDetails(breed) {
    // Update page title
    pageTitle.textContent = `${breed['Breed Name']} - Dogomo`;
    
    // Update dog details
    dogName.textContent = breed['Breed Name'];
    dogImage.src = breed.image;
    dogImage.alt = breed['Breed Name'];
    
    // Process traits
    const traitsArray = breed['Character Traits'].split(',').map(trait => trait.trim());
    const traitBadges = traitsArray.map(trait => 
      `<span class="badge bg-secondary trait-badge">${trait}</span>`
    ).join(' ');
    dogTraits.innerHTML = traitBadges;
    
    // Update other details
    dogPrice.textContent = `₹${breed['Price']}`;
    dogMaintenance.textContent = `₹${breed['Maintainance per month']}/month`;
    dogLifespan.textContent = `${breed['Longitivity']} years`;
    dogTempRange.textContent = `${breed['Min Temp']}°C to ${breed['Max Temp']}°C`;
    
    // Hide loading, show details
    loadingIndicator.classList.add('d-none');
    dogDetails.classList.remove('d-none');
  }
  
  // Show error message
  function showError(message) {
    loadingIndicator.classList.add('d-none');
    errorMessage.textContent = message;
    errorContainer.classList.remove('d-none');
  }
  
  // Start fetching data
  fetchDogDetails();
});
import pandas as pd
import os
import logging
from typing import Dict, List, Any

# Set up logging
logger = logging.getLogger(__name__)

def recommend_dogs(traits: str, budget: int, longevity: int, min_temp: int, max_temp: int, csv_path: str) -> Dict[str, List[Dict[str, Any]]]:
    """
    Recommend dog breeds based on user preferences.
    
    Args:
        traits: Desired character traits as a string
        budget: Maximum budget for the dog
        longevity: Minimum lifespan in years
        min_temp: Minimum temperature the dog can handle
        max_temp: Maximum temperature the dog can handle
        csv_path: Path to the CSV file with dog breed data
    
    Returns:
        Dictionary with recommended and not_recommended breeds
    """
    try:
        # Load the dataset
        logger.debug(f"Loading dog data from {csv_path}")
        df = pd.read_csv(csv_path)
        
        # Process the Price column (remove range and convert to numeric)
        df["Price_Processed"] = df["Price"].apply(lambda x: int(str(x).split("-")[0].strip()) if pd.notna(x) else 0)
        
        # Process the Longitivity column (extract minimum value from range)
        df["Longevity_Min"] = df["Longitivity"].apply(
            lambda x: int(str(x).split("-")[0]) if pd.notna(x) and "-" in str(x) else 
                     (int(x) if pd.notna(x) else 0)
        )
        
        # Filter based on criteria
        if traits:
            match_traits = df["Character Traits"].str.contains(traits, case=False, na=False)
        else:
            # If no traits specified, consider all breeds as matching
            match_traits = pd.Series([True] * len(df))
            
        recommended = df[
            (df["Price_Processed"] <= budget) &
            (df["Longevity_Min"] >= longevity) &
            (df["Min Temp"] <= min_temp) &
            (df["Max Temp"] >= max_temp) &
            match_traits
        ]
        
        not_recommended = df.drop(recommended.index)
        
        # Fields to include in the response
        fields = ["Breed Name", "Maintainance per month", "Character Traits", "Longitivity", "Price", "Min Temp", "Max Temp"]
        
        # Convert to list of dictionaries for JSON serialization
        def process_breed_data(row):
            data = {field: row[field] for field in fields if field in row.index}
            
            # Generate a placeholder image URL (using breed name as identifier)
            breed_name = row["Breed Name"]
            image_url = f"/static/assets/dog_default.svg"
            
            data["image"] = image_url
            return data
        
        recommended_list = [process_breed_data(row) for _, row in recommended.iterrows()]
        not_recommended_list = [process_breed_data(row) for _, row in not_recommended.iterrows()]
        
        logger.debug(f"Found {len(recommended_list)} recommended breeds and {len(not_recommended_list)} non-recommended breeds")
        
        return {
            "recommended": recommended_list,
            "not_recommended": not_recommended_list
        }
    
    except Exception as e:
        logger.error(f"Error in recommendation engine: {str(e)}", exc_info=True)
        return {
            "recommended": [],
            "not_recommended": [],
            "error": str(e)
        }
